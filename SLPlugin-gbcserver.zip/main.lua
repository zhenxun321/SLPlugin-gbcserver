function onLoad()
  sl.log.info("[gbcserver-helper] loaded")
end

function onEnable()
  sl.log.info("[gbcserver-helper] enabled")
end

function onDisable()
  sl.log.info("[gbcserver-helper] disabled")
end